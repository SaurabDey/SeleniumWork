package com.psl;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Iframeswitch 
{
	WebDriver driver;

	public Iframeswitch(WebDriver driver)
	{
		this.driver= driver;
		
	}
	
	public void frame() throws InterruptedException
	{
		
		driver.navigate().to("http://selenium.googlecode.com/svn/trunk/docs/api/java/index.html");
		
		
		
		driver.switchTo().frame("classFrame");
		driver.findElement(By.linkText("Deprecated")).click();
		
		driver.switchTo().defaultContent();
		
		
		Thread.sleep(3000);
		driver.switchTo().frame("packageListFrame");
		driver.findElement(By.linkText("com.thoughtworks.selenium")).click();
		
	}
}
