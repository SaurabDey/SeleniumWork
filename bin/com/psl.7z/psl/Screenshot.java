package com.psl;


import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


public class Screenshot {

	//static int fileCounter = 0;
	
	public void shots() throws IOException {
		
		File scrFile = ((TakesScreenshot)Global.driver).getScreenshotAs(OutputType.FILE);
        // now save the screenshot to a file some place
		
        FileUtils.copyFile(scrFile, new File("E:\\Study\\Selenium\\Selenium webdriver\\snaps\\screenshot.png"));

        
        
        
        
        
        
        
        
        
        
        
        
        
//        String fileName = "E:\\Study\\Selenium\\Selenium webdriver\\snaps\\screenshot-" + Screenshot.fileCounter++ + ".png";
//		File fileObj = new File(fileName);
//		while(fileObj.exists())
//		{
//			fileName = fileName.replaceAll(".png", "");
//			fileName = fileName + Screenshot.fileCounter++ + ".png";
//			fileObj = null;
//			fileObj = new File(fileName);
//		}
//		FileUtils.copyFile(scrFile, fileObj);
	}
}
