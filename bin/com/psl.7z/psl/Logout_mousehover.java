package com.psl;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;


public class Logout_mousehover {

	public void logout() {
		
		WebElement profile=Global.driver.findElement(By.id("wp-admin-bar-my-account"));
		
		Actions hovering=new Actions(Global.driver);
		hovering.moveToElement(profile).build().perform();
		
		Global.driver.findElement(By.id("wp-admin-bar-logout")).click();
		
		//Global.driver.findElement(By.cssSelector("a:contains('Log Out')")).click();
		
		System.out.println("Logged out successfully");
	}
}
