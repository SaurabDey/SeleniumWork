package com.psl;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class LoginPageobject 
{
	
	@FindBy (id="user_login")
	public WebElement userName;
	
	@FindBy (id="user_pass")
    public WebElement userPass;
	
	@FindBy (id="wp-submit")
	public WebElement loginbutton;
	
	public void enteruser(String userID) {
		userName.clear();
		userName.sendKeys(userID);
	}
	
	public void enterpass(String passWord) {
		userPass.clear();
		userPass.sendKeys(passWord);
	}
	
	public void pressloginbtn() {
		loginbutton.click();
	
	}
	
	public void loginPage(String userID,String passWord) 
	{
		enteruser(userID);
		enterpass(passWord);
		pressloginbtn();
		
	}
	
	
}
