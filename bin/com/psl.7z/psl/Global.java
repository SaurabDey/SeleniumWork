package com.psl;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.openqa.selenium.WebDriver;


public class Global {
	
	public static WebDriver driver;
	public static Workbook excel;
	public static Sheet sheet;
	
	
	public static WritableWorkbook excel1;
	
	public static WritableSheet sheet1;
	
}
