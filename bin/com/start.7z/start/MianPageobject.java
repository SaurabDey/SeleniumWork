package com.start;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.support.PageFactory;

import com.psl.Dashboard_DragnDrop;
import com.psl.Dashboard_checkbox;
import com.psl.Global;
import com.psl.LoginPageobject;

public class MianPageobject {

	public static void main(String[] args) throws IOException, InterruptedException 
	{
		setup();
		
		String userID="selenium";
		String passWord="selenium123";
		
		LoginPageobject login= PageFactory.initElements(Global.driver,LoginPageobject.class);
		login.loginPage(userID, passWord);
		
		Dashboard_DragnDrop d= new Dashboard_DragnDrop();
		d.drag();
		
		teardown();
		
	}

	public static void setup() throws IOException {
		
		System.setProperty("webdriver.ie.driver", "Resource/IEDriverServer.exe");
		System.setProperty("webdriver.chrome.driver", "Resource/chromedriver.exe");

				
		Global.driver=new FirefoxDriver();

		Global.driver.get("http://localhost/wordpress/wp-login.php");

		Global.driver.manage().window().maximize();

		//implicit wait
		Global.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public static void teardown() 
	{
		Global.driver.quit();
		
	
	}
}
